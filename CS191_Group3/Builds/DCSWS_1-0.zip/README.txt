CS 191 WFR - GROUP 3
DCS WALKING SIMULATOR
--------------------------

== ABOUT THE BUILD ==

The prototype features the ability to traverse the first three floors of DCS and the layout of the rooms.

Not included in current prototype are the following:
- The ability to go inside rooms
- Engglib2 (Basement area)
- Outside area of DCS (screenshots can be found in the PDF attached)


=== HOW TO USE THE BUILD ===

1. Execute DCS Walking Simulator.exe
2. Use the WASD keys to move around and the Spacebar to jump
3. To exit the build, use Alt + F4


== PROPONENTS ==
BAUTISTA, Lyzer
MONTECILLO, PJ
YAP, Sharlene